// JavaScript for ASH 2014 pages : banners

var googletag = googletag || {};
googletag.cmd = googletag.cmd || [];
(function() {
  var gads = document.createElement('script');
  gads.async = true;
  gads.type = 'text/javascript';
  var useSSL = 'https:' == document.location.protocol;
  gads.src = (useSSL ? 'https:' : 'http:') + 
  '//www.googletagservices.com/tag/js/gpt.js';
  var node = document.getElementsByTagName('script')[0];
  node.parentNode.insertBefore(gads, node);
})();

googletag.cmd.push(function() {
  googletag.defineSlot('/21688575/TONC_ASH_Conference_Perspectives_160x600', [[120, 600], [160, 600]], 'div-gpt-ad-1456447203161-1').addService(googletag.pubads());
  googletag.defineSlot('/21688575/TONC_ASH_Conference_Perspectives_728x90', [728, 90], 'div-gpt-ad-1456447203161-0').addService(googletag.pubads());
  googletag.pubads().enableSingleRequest();
  googletag.enableServices();
});


//js for page content
$(document).ready(function(e) {
  $('.sourcelink').attr('target','_blank');    
});
