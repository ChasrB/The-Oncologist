 $(document).ready(function(e) {
	$("div.leaderboard-ads").html("<span class='ad-leadeboard-text'>Advertisement</span>");
    
 });
