 $(document).ready(function(e) {
   
  $("div.leaderboard-ads").html("<span class='ad-leadeboard-text'>Advertisement</span><!-- TONC_ASH_Conference_Perspectives_728x90 --><div id='div-gpt-ad-1416426447146-1' style='width:728px; height:90px;'><script type='text/javascript'>googletag.cmd.push(function() { googletag.display('div-gpt-ad-1416426447146-1'); });</script></div>");
   $("#tower-ad").html("<!-- TONC_ASH_Conference_Perspectives_160x600 --><div id='div-gpt-ad-1416426447146-0'><script type='text/javascript'>googletag.cmd.push(function() { googletag.display('div-gpt-ad-1416426447146-0'); });</script></div><span class='ad-tower'>Advertisement</span>"); 

  $(".button-list").next().hide();
  $(".thirdbannerBN").hide();
  //.css( "display", "red" );


 });//end doc ready
