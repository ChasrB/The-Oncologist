// JavaScript for ASH 2016 pages : banners

var googletag = googletag || {};
googletag.cmd = googletag.cmd || [];
(function() {
  var gads = document.createElement('script');
  gads.async = true;
  gads.type = 'text/javascript';
  var useSSL = 'https:' == document.location.protocol;
  gads.src = (useSSL ? 'https:' : 'http:') + 
  '//www.googletagservices.com/tag/js/gpt.js';
  var node = document.getElementsByTagName('script')[0];
  node.parentNode.insertBefore(gads, node);
})();

googletag.cmd.push(function() {

  googletag.defineSlot('/311960950/TheOncologist.org/728x90_ROS_Top', [[728, 90], [300, 50], [320, 50]], 'div-gpt-ad-1456447203161-0').addService(googletag.pubads());
      googletag.defineSlot('/311960950/TheOncologist.org/160x600_ROS_Right1', [[160, 600], [120, 600]], 'div-gpt-ad-1456447203161-1').addService(googletag.pubads());
      googletag.defineSlot('/311960950/TheOncologist.org/160x600_ROS_Right2', [[160, 600], [120, 600]], 'div-gpt-ad-1456447203161-2').addService(googletag.pubads());
      googletag.defineSlot('/311960950/TheOncologist.org/728x90_ROS_Bottom_Anchor', [[728, 90], [300, 50], [320, 50]], 'div-gpt-ad-1456447203161-3').addService(googletag.pubads());
    
    
    

      
      googletag.pubads().setTargeting("url","/legacyproxy/site/conference/ash/2016/cannelos.html").setTargeting("page","ASH_Conference_Article_Pages");
      googletag.pubads().enableSingleRequest();
      googletag.enableServices();


//js for page content
$(document).ready(function(e) {
  $('.sourcelink').attr('target','_blank');    
});
