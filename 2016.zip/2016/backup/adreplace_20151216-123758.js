 $(document).ready(function(e) {
	$("div.leaderboard-ads").html("<span class='ad-leadeboard-text'>Advertisement</span><!-- TONC_ASH_Conference_Perspectives_728x90 --><div id='div-gpt-ad-1416426447146-1' style='width:728px; height:90px;'><script type='text/javascript'>googletag.cmd.push(function() { googletag.display('div-gpt-ad-1416426447146-1'); });</script></div>");
    
 });
