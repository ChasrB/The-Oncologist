 $(document).ready(function(e) {
	googletag.cmd.push(function() {
		googletag.defineSlot('/21688575/TONC_ASH_Conference_Perspectives_160x600', [[120, 600], [160, 600]], 'div-gpt-ad-1416426447146-0').addService(googletag.pubads());
		googletag.defineSlot('/21688575/TONC_ASH_Conference_Perspectives_728x90', [728, 90], 'div-gpt-ad-1416426447146-1').addService(googletag.pubads());
		googletag.pubads().enableSingleRequest();
		googletag.enableServices();
	});

	$("div.leaderboard-ads").html("<span class='ad-leadeboard-text'>Advertisement</span><!-- TONC_ASH_Conference_Perspectives_728x90 --><div id='div-gpt-ad-1416426447146-1' style='width:728px; height:90px;'><script type='text/javascript'>googletag.cmd.push(function() { googletag.display('div-gpt-ad-1416426447146-1'); });</script></div>");
   $("#tower-ad").html("<!-- TONC_ASH_Conference_Perspectives_160x600 --><div id='div-gpt-ad-1416426447146-0'><script type='text/javascript'>googletag.cmd.push(function() { googletag.display('div-gpt-ad-1416426447146-0'); });</script></div><span class='ad-tower'>Advertisement</span>"); 

	$(".button-list pub-links").next.hide();
	$(".thirdbannerBN").hide();
	//.css( "display", "red" );


 });//end doc ready
